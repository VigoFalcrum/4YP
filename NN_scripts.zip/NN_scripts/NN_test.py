import torch
import torch.nn as nn
# Removed optim as it's not needed for testing
# Removed sklearn.datasets, sklearn.model_selection
from sklearn.preprocessing import StandardScaler # Still needed for scaler definition
from sklearn.metrics import accuracy_score, classification_report
import pandas as pd
import numpy as np
import random
import time
import sys
import joblib
import os # Added for file existence checks

# --- Configuration & Setup ---

# Set random seeds (optional for testing, but doesn't hurt)
torch.manual_seed(29)
np.random.seed(29)
random.seed(29)

# --- Argument Parsing ---
# Expects: python script_name.py <layer_width> <depth> <cores>
if len(sys.argv) != 4:
    print("Usage: python NN_test_perf.py <layer_width> <depth> <cores>")
    print("Example: python NN_test_perf.py 64 5 4")
    sys.exit(1) # Exit if incorrect number of arguments

try:
    layer_width = int(sys.argv[1])
    nn_depth = int(sys.argv[2])
    cores = int(sys.argv[3])
except ValueError:
    print("Error: layer_width, depth, and cores must be integers.")
    sys.exit(1)

# --- Device and Threading ---
# Limit the CPU thread count
try:
    torch.set_num_threads(cores)
    # print(f"Torch threads set to: {torch.get_num_threads()}") # Optional: verify
except Exception as e:
    print(f"Warning: Could not set torch threads: {e}", file=sys.stderr)

# Use CPU for consistency with training/testing setup
device = torch.device('cpu')

# --- Data Definitions (Consistent with Training) ---
datatypes = {'srcip' : int, 'sport' : int, 'dstip' : int, 'dsport' : int, 'proto' : int, 'state' : int, 'dur' : float, \
             'sbytes' : int, 'dbytes' : int, 'sttl' : int, 'dttl' : int, 'sloss' : int, 'dloss' : int, 'service' : int, \
             'Sload' : float, 'Dload' : float, 'Spkts' : int, 'Dpkts' : int, 'swin' : int, 'dwin' : int, 'stcpb' : int, \
             'dtcpb' : int, 'smeansz' : int, 'dmeansz' : int, 'trans_depth' : int, 'res_bdy_len' : int, 'Sjit' : float, \
             'Djit' : float, 'Sintpkt' : float, 'Dintpkt' : float, 'tcprtt' : float, \
             'synack' : float, 'ackdat' : float, 'is_sm_ips_ports' : int, 'ct_state_ttl' : int, 'ct_flw_http_mthd' : int, \
             'ct_srv_src' : int, 'ct_srv_dst' : int, 'ct_dst_ltm' : int, \
             'ct_src_ltm' : int, 'ct_src_dport_ltm' : int, 'ct_dst_sport_ltm' : int, 'ct_dst_src_ltm' : int}

col_names = ['srcip', 'sport', 'dstip', 'dsport', 'proto', 'state', 'dur', 'sbytes', 'dbytes', 'sttl', 'dttl', 'sloss', \
             'dloss', 'service', 'Sload', 'Dload', 'Spkts', 'Dpkts', 'swin', 'dwin', 'stcpb', 'dtcpb', 'smeansz', 'dmeansz', \
             'trans_depth', 'res_bdy_len', 'Sjit', 'Djit', 'Sintpkt', 'Dintpkt', 'tcprtt', 'synack', \
             'ackdat', 'is_sm_ips_ports', 'ct_state_ttl', 'ct_flw_http_mthd', 'ct_srv_src', \
             'ct_srv_dst', 'ct_dst_ltm', 'ct_src_ltm', 'ct_src_dport_ltm', 'ct_dst_sport_ltm', 'ct_dst_src_ltm']

# --- Load ONLY Test Data ---
X_test_data_path = 'X_test.parquet'
y_test_data_path = 'y_test.parquet'

try:
    X_test_df = pd.read_parquet(X_test_data_path)
    y_test_df = pd.read_parquet(y_test_data_path)
except FileNotFoundError:
    print(f"Error: Test data files not found at '{X_test_data_path}' or '{y_test_data_path}'")
    sys.exit(1)
except Exception as e:
    print(f"Error loading test data: {e}")
    sys.exit(1)

# --- Preprocess Test Data ---
try:
    X_test_df = X_test_df.astype(datatypes)
    X_test_df.columns = col_names
    y_test_df.columns = ['label']

    # Drop first row (if this was consistently done during training data prep)
    if not X_test_df.empty:
        X_test_df = X_test_df.drop(X_test_df.index[0])
    if not y_test_df.empty:
        y_test_df = y_test_df.drop(y_test_df.index[0])

    # Squeeze y_test (results in a Pandas Series)
    y_test_series = y_test_df.squeeze()

    if X_test_df.empty or y_test_series.empty:
        print("Error: Test data is empty after preprocessing.")
        sys.exit(1)

except Exception as e:
    print(f"Error during basic data preprocessing: {e}")
    sys.exit(1)

# --- Load Scaler (Trained Artefact) ---
scaler_pkl = f"scaler_{nn_depth}_{layer_width}.pkl"

if not os.path.exists(scaler_pkl):
    print(f"Error: Scaler file not found: {scaler_pkl}")
    print("Ensure you have trained a model with these parameters (depth, width) first.")
    sys.exit(1)

try:
    scaler = joblib.load(scaler_pkl)
except Exception as e:
    print(f"Error loading scaler file '{scaler_pkl}': {e}")
    sys.exit(1)


# --- Scale Test Data using LOADED Scaler ---
try:
    # Use .values to get NumPy array from DataFrame for scaler
    X_test_scaled_np = scaler.transform(X_test_df)
except ValueError as e:
    print(f"Error applying loaded scaler: {e}")
    print("This might indicate a mismatch between features in training and testing, or an issue with the scaler file.")
    sys.exit(1)
except Exception as e:
    print(f"An unexpected error occurred during scaling: {e}")
    sys.exit(1)


# --- Convert Data to Tensors ---
try:
    X_test_tensor = torch.tensor(X_test_scaled_np, dtype=torch.float32).to(device)
    # Use .values on the Pandas Series to get NumPy array for tensor conversion
    y_test_tensor = torch.tensor(y_test_series.values, dtype=torch.long).to(device)
except Exception as e:
    print(f"Error converting data to tensors: {e}")
    sys.exit(1)


# --- Define the Neural Network (must match training structure) ---
class DeepNN(nn.Module):
    def __init__(self, input_size, hidden_size, num_hidden_layers, num_classes):
        super(DeepNN, self).__init__()
        layers = []

        if num_hidden_layers <= 0:
             # Handle case with no hidden layers (direct input to output)
             layers.append(nn.Linear(input_size, num_classes))
        elif num_hidden_layers == 1:
             # Handle case with only one hidden layer
             layers.append(nn.Linear(input_size, hidden_size))
             layers.append(nn.ReLU())
             layers.append(nn.Linear(hidden_size, num_classes))
        else: # num_hidden_layers >= 2
             # First layer: from input to hidden_size
             layers.append(nn.Linear(input_size, hidden_size))
             layers.append(nn.ReLU())

             # Hidden layers: hidden_size -> hidden_size
             # Loop needs to run num_hidden_layers - 2 times
             for _ in range(num_hidden_layers - 2):
                 layers.append(nn.Linear(hidden_size, hidden_size))
                 layers.append(nn.ReLU())

             # Final layer: from hidden_size to num_classes
             layers.append(nn.Linear(hidden_size, num_classes))

        self.network = nn.Sequential(*layers)

    def forward(self, x):
        return self.network(x)

# --- Instantiate Model and Load State (Trained Artefact) ---
model_pth = f"NN_{nn_depth}_{layer_width}.pth"

if not os.path.exists(model_pth):
    print(f"Error: Model file not found: {model_pth}")
    print("Ensure you have trained a model with these parameters (depth, width) first.")
    sys.exit(1)

# Determine input size and number of classes from the data
input_size = X_test_tensor.shape[1]
try:
    # Use .values on the Pandas Series to get NumPy array for np.unique
    num_classes = len(np.unique(y_test_series.values))
    if num_classes < 2:
         print(f"Warning: Detected only {num_classes} class(es) in the test labels. Ensure this is correct.")
except Exception as e:
    print(f"Error determining number of classes from test labels: {e}")
    sys.exit(1)


# Create model instance matching the loaded state's architecture
# Using parsed layer_width for hidden_size and nn_depth for num_hidden_layers
try:
    model = DeepNN(input_size, layer_width, nn_depth, num_classes).to(device)
    model.load_state_dict(torch.load(model_pth, map_location=device))
except RuntimeError as e:
     print(f"Error: Failed to load model state dict from '{model_pth}': {e}")
     print("This often means the model architecture defined here (depth, width, classes) does not match the saved file.")
     sys.exit(1)
except FileNotFoundError:
     print(f"Error: Model file not found during load_state_dict (should have been caught earlier): {model_pth}")
     sys.exit(1)
except Exception as e:
    print(f"An unexpected error occurred loading model state: {e}")
    sys.exit(1)

# --- Set Model to Evaluation Mode ---
model.eval()

# --- Perform Inference ---
try:
    start_time = time.perf_counter()
    for i in range(20):
        with torch.no_grad(): # Disable gradient calculations for inference
            outputs = model(X_test_tensor)
    end_time = time.perf_counter()
    inference_time = end_time - start_time
    print(inference_time/20)

    # --- Calculate Predictions ---
    # Get the index of the max log-probability (predicted class)
    _, predicted_labels = torch.max(outputs, 1)

except Exception as e:
    print(f"Error during model inference: {e}")
    sys.exit(1)
